import pandas as pd
import numpy as np
from pandas import Series,DataFrame
import matplotlib.pyplot as plt
import glob

# loading CSV files
csv_files=glob.glob("*.csv")
frame=[]
for file in csv_files:
    frame.append(pd.read_csv(file))
#print(frame)
us_census=pd.concat(frame)
print(us_census.head())


# Checking columns
#print(us_census.columns)

# checking Data type
#print(us_census.dtypes)

# columns convert to their right type (manipulation)
us_census['Income']=pd.to_numeric(us_census['Income'].replace('\$','',regex=True))
us_census['Pacific']=pd.to_numeric(us_census['Pacific'].str.replace('%',''))
us_census['Asian']=pd.to_numeric(us_census['Asian'].str.replace('%',''))
us_census['Hispanic']=pd.to_numeric(us_census['Hispanic'].str.replace('%',''))
us_census['White']=pd.to_numeric(us_census['White'].str.replace('%',''))
us_census['Black']=pd.to_numeric(us_census['Black'].str.replace('%',''))
us_census['Native']=pd.to_numeric(us_census['Native'].str.replace('%',''))

# spliting GerderPop into two new column Men and Women
us_census[['Men','Women']]=us_census['GenderPop'].str.split('_',expand=True)

# Removing M and F character and Convert to its right type
us_census['Men']=pd.to_numeric(us_census['Men'].str.replace('[,M]','',regex=True))
us_census['Women']=pd.to_numeric(us_census['Women'].str.replace('[,F]','',regex=True))

x=us_census['Women']
y=us_census['Income']
plt.scatter(x,y)
plt.show()

# filling nan value in column women with total pop per state minus men per state
us_census['Women']=us_census['Women'].fillna(us_census['TotalPop']-us_census['Men'])

#print(us_census['Women'])
#print(us_census.duplicated())
print(us_census.duplicated().value_counts())
#print(us_census.drop_duplicates())
us_census=us_census.drop_duplicates()

# making scatter plot
plt.scatter(us_census['Women']/us_census['TotalPop'],us_census['Income'])
plt.xlabel('Porportion of Women')
plt.ylabel('Average Income')
plt.show()

# filling up missing value with 0's in the following given column
us_census=us_census.fillna(value={'Asian':0,'Black':0,'White':0,'Pacific':0,'Hispanic':0,'Native':0})

# All Histogram
plt.hist(us_census['Asian'],color='green')
plt.xlabel('%age of Asian Population')
plt.ylabel('count')
plt.show()

plt.hist(us_census['Black'],color='grey')
plt.xlabel('%age of Black Population')
plt.ylabel('count')
plt.show()

plt.hist(us_census['White'],color='yellow')
plt.xlabel('%age of White Population')
plt.ylabel('count')
plt.show()
 
plt.hist(us_census['Native'],color='red')
plt.xlabel('%age of Native Population')
plt.ylabel('count')
plt.show()

plt.hist(us_census['Hispanic'],color='pink')
plt.xlabel('%age of Hispanic Population')
plt.ylabel('count')
plt.show()

plt.hist(us_census['Pacific'],color='purple')
plt.xlabel('%age of Pacific Population')
plt.ylabel('count')
plt.show()


